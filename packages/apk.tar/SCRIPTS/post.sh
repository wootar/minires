#!/bin/sh
url="https://dl-cdn.alpinelinux.org/alpine/edge/main/x86_64/apk-tools-static-2.12.9-r2.apk"
echo "[-] Preparing"
mkdir /tmp/wagon
cd /tmp/wagon
wget -O apk.tar.gz $URL
mkdir root
mkdir backup
cp -rv /etc backup/etc
tar xvf apk.tar.gz
echo "[-] Now restoring APK!"
./sbin/apk.static --arch $(arch) -X http://dl-cdn.alpinelinux.org/alpine/edge/main/ -U --allow-untrusted --root /tmp/wagon/root --initdb add alpine-base || echo "Failed to restore APK"; exit 1
cp -rv root/* /
cp -rv backup/* /
echo "[-] Done!"
exit 0
